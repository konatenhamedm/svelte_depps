<?php
	
	require "../_class/routes.php";

	#start index;
	routes::index();
