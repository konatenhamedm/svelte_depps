
<footer class="main-footer bt-1">
    <div class="pull-right max-[575px]:hidden min-[576px]:inline-flex">
         <ul class="nav nav-primary nav-dotted nav-dot-separated justify-center justify-content-md-end">
            <li class="nav-item">
                 <a class="nav-link text-blue-500 hover:text-gray-500" href="#" target="_blank">Purchase Now</a>
            </li>
         </ul>
    </div>
     &copy; <script>document.write(new Date().getFullYear())</script> <a href="https://www.multipurposethemes.com/">Multipurpose Themes</a>. All Rights Reserved.

     
    <script
    type="text/javascript"
    src="/cdnjs.cloudflare.com/ajax/libs/jQuery-slimScroll/1.3.8/jquery.slimscroll.min.js"></script>
  <!-- Vendor JS -->
  <script src="/js/vendors.min.js"></script>
  <script src="/js/pages/chat-popup.js"></script>
  <script src="/assets/icons/feather-icons/feather.min.js"></script>
  <script src="/assets/vendor_components/Flot/jquery.flot.js"></script>
  <script src="/assets/vendor_components/Flot/jquery.flot.resize.js"></script>
  <script src="/assets/vendor_components/Flot/jquery.flot.pie.js"></script>
  <script src="/assets/vendor_components/Flot/jquery.flot.categories.js"></script>
  <script src="/assets/vendor_components/echarts/dist/echarts-en.min.js"></script>
  <script src="/assets/vendor_components/apexcharts-bundle/dist/apexcharts.js"></script>

  <script src="/cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment-with-locales.min.js"></script>
  <script src="/assets/vendor_components/c3/d3.min.js"></script>
  <script src="/assets/vendor_components/c3/c3.min.js"></script>
  <script src="/assets/vendor_components/raphael/raphael.min.js"></script>
  <script src="/assets/vendor_components/morris.js/morris.min.js"></script>

  
  <script src="/js/tailwind.min.js"></script>
  <!-- CRMHQ Admin App -->
  <script src="/js/demo.js"></script>
  <script src="/js/template.js"></script>
  <script src="/js/pages/dashboard2.js"></script>
  <script src="/js/pages/calendar.js"></script>
  
</footer>

