<footer class="footer">
    <!--footer menu-->           
    <div class="tablo">
        <div class="ozel">
            <div class="tablo--1-ve-3">
                <h2 class="h2-baslik-footer h-yazi-margin-kucuk"> CONTACTS </h2> 
                <div class="footerss">
                    <p><strong>TELEPHONE : </strong> (225) 27 20 32 46 32 (225) 05 66 05 60 60</p>
                    <p><strong>MAIL : </strong> secretariatdeps2@gmail.com</p>
                    <p><strong>ADRESSE : </strong> secretariatdeps2@gmail.com</p>
                </div>                  
            </div>
            <div class="tablo--1-ve-3">
                <h2 class="h2-baslik-footer h-yazi-margin-kucuk"> LIENS </h2> 
                <div class="footer__menu">
                    <ul style="padding-left: 0px;" class="footer__list"> 
                        <li class="footer__item"><a href="accueil" class="footer__link">Accueil</a></li>
                        <li class="footer__item"><a href="E-DEPPS" class="footer__link">E-DEPPS</a></li>
                        <li class="footer__item"><a href="a-propos" class="footer__link">A propos</a></li>
                        <li class="footer__item"><a href="contactez-nous" class="footer__link">Contactez-nous</a></li>
                    </ul>      
                </div>                   
            </div>
        <div class="tablo--1-ve-3">
            <h2 class="h2-baslik-footer h-yazi-margin-kucuk"> RÉSEAUX SOCIAUX </h2> 
            <p class="footer__sosyal">
                    <a href="#" class="footer__sosyallink">.facebook</a>&nbsp;
                    <a href="#" class="footer__sosyallink">.instagram</a> &nbsp;
                    <a href="#" class="footer__sosyallink">.twitter</a>&nbsp;
                    <a href="#" class="footer__sosyallink">.linkedin</a>
        </p></div></div>
    </div>
    <div class="ozel-copyright">
        <div class="footer__copyright">
            © 2025 - My DEPPS.
        </div>
    </div>
    <div id="top" style="cursor: pointer; display: block;">
        <img width="50" height="50" src="/site/img/go-top.png" alt="">
    </div>
    <script type="text/javascript" async="" charset="utf-8" src="https://www.gstatic.com/recaptcha/releases/I0bG74fWAenNf3Z5ncHSz-bd/recaptcha__fr.js" crossorigin="anonymous" integrity="sha384-SuLEVo1wb8QhuPsIZMqOg4KgVlwDLK5gQPeMMg8TKAxgTarbThNYStXtyYDtOWR/"></script><script src="js/jquery.min.js"></script> 
    <script src="/site/js/imagesloaded.pkgd.min.js"></script> 
    <script src="/site/js/isotope.min.js"></script> 
    <script src="/site/js/swiper.min.js"></script> 
    <script src="/site/js/TweenMax.min.js"></script> 
    <script src="/site/js/odometer.min.js"></script> 
    <script src="/site/js/fancybox.min.js"></script> 
    <script src="/site/js/wow.min.js"></script> 
    <script src="/site/js/scripts.js"></script>  
    <script src="/site/js/jquery.min.js"></script>  
    <script src="/site/js/pointer.js"></script>
    <script src="/site/js/BeerSlider.unmin.js"></script>

    <script src="https://www.google.com/recaptcha/api.js" async="" defer=""></script>
    <!-- Toastr CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.7/jquery.inputmask.min.js" integrity="sha512-jTgBq4+dMYh73dquskmUFEgMY5mptcbqSw2rmhOZZSJjZbD2wMt0H5nhqWtleVkyBEjmzid5nyERPSNBafG4GQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
      $(".phone-ci").inputmask("225 99 999 999 99",{placeholder:""});
    </script>
                    <!--Cursor Script-->                    
    <script>
        init_pointer({
            
        })
    </script>
    <script>
        $(document).ready(function(){
        $(".tabs-content").eq(0).show();
        $("#tabs li").eq(0).addClass("button-renk");
        $("#tabs li").click(function(){
        var number = $(this).index();
        $("#tabs li").removeClass("button-renk");
        $(".tabs-content").hide().eq(number).fadeIn("slow");
        $("#tabs li").eq(number).addClass("button-renk");
        });
        });
    </script>
    <script>
        $(function() {
            $("#top").click(function() {
                $("html,body").stop().animate({ scrollTop: "0" }, 100);
            });
        });
        $(window).scroll(function() {
            var uzunluk = $(document).scrollTop();
            if (uzunluk > 300) $("#top").fadeIn(500);
            else { $("#top").fadeOut(500); }
        });
    </script>
            
    <script>
        $.fn.BeerSlider = function ( options ) {
            options = options || {};
            return this.each(function() {
            new BeerSlider(this, options);
            });
        };
        $('.beer-slider').BeerSlider({start: 50});
    </script>
</footer>