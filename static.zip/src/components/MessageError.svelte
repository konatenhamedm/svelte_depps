<div class="grid grid-cols-1">
<h2 class="fw-bolder fs-2qx text-red-900 " style="color:orangered">
    Vous n'avez pas les droits néccessaires pour lire Cette ressource
</h2>
<img src="/oups.jpg" class="" alt="" />
</div>


