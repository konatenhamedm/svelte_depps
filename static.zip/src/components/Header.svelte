<script>


</script>

<div class="navigation-menu">
    <div class="inner">
        <div class="side-menu">
        <ul>
            <li><a href="accueil">Accueil</a></li>
            <li><a href="a-propos">A propos</a></li>
            <li><a href="E-DEPPS">E-DEPPS</a></li>
            <li><a href="contactez-nous">Contactez-nous</a></li>
            <li><a href="/site/inscription">Inscription</a></li>
            <li><a href="connexion">Connexion</a></li>
        </ul>
        </div>
    </div>
</div>  
  <div class="sides">
  </div>

  <style>
    .navbar .logo a img {
      height: 89px;
    }
    .navbar {
      width: 100%;
      display: flex;
      flex-wrap: wrap;
      position: fixed;
      z-index: 9;
      background: white;
      padding: 3px 15px;
    }
    .header .navbar {
      width: 100%;
      margin-bottom: 0;
      box-shadow: 0px 2px 10px #ddd;
    }
    .navbar .logo {
      margin-left: 54px;
    }
  </style>