<script>

</script>

<li class="menu-title s-uS8xQf-YCDiO">
    <div class="animate-pulse bg-gray-300 h-4 w-48 mb-2"></div>
</li>
<li class="s-uS8xQf-YCDiO ">
    <a class="has-arrow s-uS8xQf-YCDiO" href="javascript:void(0);">
        <!-- <div class="menu-icon s-uS8xQf-YCDiO">
            <div class="bg-gray-300 w-[25px] h-[25px] mt-[10px] rounded"></div>
        </div> -->
        <span class="nav-text s-uS8xQf-YCDiO">
            <div class="animate-pulse bg-gray-300 h-4 w-48"></div>
        </span>
    </a>
    <ul class="sub-menu mm-collapse mm-show left s-uS8xQf-YCDiO">
        <li class="s-uS8xQf-YCDiO">
            <a href="/admin/role" class="s-uS8xQf-YCDiO">
                <div class="animate-pulse bg-gray-300 h-4 w-40"></div>
            </a>
        </li>
        <li class="s-uS8xQf-YCDiO">
            <a href="/admin/feature" class="s-uS8xQf-YCDiO">
                <div class="animate-pulse bg-gray-300 h-4 w-40"></div>
            </a>
        </li>
        <li class="s-uS8xQf-YCDiO">
            <a href="/admin/permission" class="s-uS8xQf-YCDiO">
                <div class="animate-pulse bg-gray-300 h-4 w-40"></div>
            </a>
        </li>
        <li class="s-uS8xQf-YCDiO">
            <a href="/admin/icons" class="s-uS8xQf-YCDiO">
                <div class="animate-pulse bg-gray-300 h-4 w-40"></div>
            </a>
        </li>
        <li class="s-uS8xQf-YCDiO">
            <a href="/admin/modules" class="s-uS8xQf-YCDiO">
                <div class="animate-pulse bg-gray-300 h-4 w-40"></div>
            </a>
        </li>
        <li class="s-uS8xQf-YCDiO">
            <a href="/admin/sous-menu" class="s-uS8xQf-YCDiO">
                <div class="animate-pulse bg-gray-300 h-4 w-40"></div>
            </a>
        </li>
        <li class="s-uS8xQf-YCDiO">
            <a href="/admin/pays" class="s-uS8xQf-YCDiO">
                <div class="animate-pulse bg-gray-300 h-4 w-40"></div>
            </a>
        </li>
    </ul>
</li>