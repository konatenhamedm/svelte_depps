<div role="status" class="animate-pulse w-full">
    <div class="flex space-x-4">
        <!-- Dropdown 1 Simulation -->
        <div class="h-10 bg-gray-200 rounded dark:bg-gray-700 flex-1"></div>

        <!-- Dropdown 2 Simulation -->
        <div class="h-10 bg-gray-200 rounded dark:bg-gray-700 flex-1"></div>

        <!-- Dropdown 3 Simulation -->
        <div class="h-10 bg-gray-200 rounded dark:bg-gray-700 flex-1"></div>
    </div>
    
    <!-- Other loading sections -->
    <div class="h-2.5 bg-gray-200 rounded-full dark:bg-gray-700 w-full mt-4 mb-4"></div>
    <div class="h-2 bg-gray-200 rounded-full dark:bg-gray-700 w-3/4 mb-2.5"></div>
    <div class="h-2 bg-gray-200 rounded-full dark:bg-gray-700 w-1/2 mb-2.5"></div>
    
    <span class="sr-only">Loading...</span>
</div>
