export const  BASE_URL = 'http://localhost:5173'; // Remplacez par l'URL de votre API
export const  BASE_URL_API = 'https://h940a7rlc1.execute-api.us-east-1.amazonaws.com/devlebedoo/payments/payment-links/v1'; // Remplacez par l'URL de votre API
