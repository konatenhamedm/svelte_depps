export { matchers } from './matchers.js';

export const nodes = [
	() => import('./nodes/0'),
	() => import('./nodes/1'),
	() => import('./nodes/2'),
	() => import('./nodes/3'),
	() => import('./nodes/4'),
	() => import('./nodes/5'),
	() => import('./nodes/6'),
	() => import('./nodes/7'),
	() => import('./nodes/8'),
	() => import('./nodes/9'),
	() => import('./nodes/10'),
	() => import('./nodes/11'),
	() => import('./nodes/12'),
	() => import('./nodes/13'),
	() => import('./nodes/14'),
	() => import('./nodes/15'),
	() => import('./nodes/16'),
	() => import('./nodes/17'),
	() => import('./nodes/18'),
	() => import('./nodes/19'),
	() => import('./nodes/20'),
	() => import('./nodes/21'),
	() => import('./nodes/22'),
	() => import('./nodes/23'),
	() => import('./nodes/24'),
	() => import('./nodes/25'),
	() => import('./nodes/26'),
	() => import('./nodes/27'),
	() => import('./nodes/28'),
	() => import('./nodes/29'),
	() => import('./nodes/30'),
	() => import('./nodes/31')
];

export const server_loads = [];

export const dictionary = {
		"/": [2],
		"/admin": [3],
		"/admin/administrateur": [4],
		"/admin/civilite": [5],
		"/admin/destinataire": [6],
		"/admin/etablissements": [7],
		"/admin/genre": [8],
		"/admin/historique_paiement": [9],
		"/admin/liste-de-codes": [10],
		"/admin/pays": [11],
		"/admin/professionnel_accepte": [12],
		"/admin/professionnel_ajour": [13],
		"/admin/professionnel_attente": [14],
		"/admin/professionnel_refuse": [15],
		"/admin/professionnel_renouvellement": [16],
		"/admin/professionnel_valide": [17],
		"/admin/specialite": [18],
		"/admin/statistique/genre": [19],
		"/admin/statistique/geolocalisation": [20],
		"/admin/statistique/specialite": [21],
		"/admin/type_personne": [22],
		"/login": [23],
		"/site/connexion": [24],
		"/site/dashboard": [25],
		"/site/documents": [26],
		"/site/informations": [27],
		"/site/inscription": [28],
		"/site/organisation": [29],
		"/site/paiement": [30],
		"/site/professionnel": [31]
	};

export const hooks = {
	handleError: (({ error }) => { console.error(error) }),
	
	reroute: (() => {}),
	transport: {}
};

export const decoders = Object.fromEntries(Object.entries(hooks.transport).map(([k, v]) => [k, v.decode]));

export const hash = false;

export const decode = (type, value) => decoders[type](value);

export { default as root } from '../root.js';